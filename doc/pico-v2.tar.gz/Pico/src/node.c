#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "node.h"


Node * syntax_tree;

Node* create_node(int nl, Node_type t,
        char* lexeme, Node* child0, ...) {
  /* a implementar */
  return(NULL);   /* a alterar... */
}

/* Implementar as funcoes definidas em node.h */
